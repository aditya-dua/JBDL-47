package org.springboot.into.l11_sb_Curd.L11_SpringBoot_CURD_API_Example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L11SpringBootCurdApiExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(L11SpringBootCurdApiExampleApplication.class, args);
	}

}
