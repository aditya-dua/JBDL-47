package org.springboot.into.l11_sb_Curd.L11_SpringBoot_CURD_API_Example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L11SpringBootCurdApiExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
