package org.gfg.l20_swagger_sb.L20_Swagger_SB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L20SwaggerSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
