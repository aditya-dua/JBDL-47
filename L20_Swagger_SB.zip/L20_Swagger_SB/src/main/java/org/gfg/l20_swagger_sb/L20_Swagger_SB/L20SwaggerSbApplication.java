package org.gfg.l20_swagger_sb.L20_Swagger_SB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L20SwaggerSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(L20SwaggerSbApplication.class, args);
	}

}
