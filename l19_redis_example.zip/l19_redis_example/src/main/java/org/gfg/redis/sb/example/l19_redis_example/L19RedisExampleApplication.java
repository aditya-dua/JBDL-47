package org.gfg.redis.sb.example.l19_redis_example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L19RedisExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(L19RedisExampleApplication.class, args);
	}

}
