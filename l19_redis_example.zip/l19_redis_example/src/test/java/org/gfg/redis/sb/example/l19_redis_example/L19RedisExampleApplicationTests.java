package org.gfg.redis.sb.example.l19_redis_example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L19RedisExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
