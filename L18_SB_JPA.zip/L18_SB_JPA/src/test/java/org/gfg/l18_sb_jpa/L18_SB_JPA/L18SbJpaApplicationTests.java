package org.gfg.l18_sb_jpa.L18_SB_JPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L18SbJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
