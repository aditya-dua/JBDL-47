package org.gfg.l18_sb_jpa.L18_SB_JPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L18SbJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(L18SbJpaApplication.class, args);
	}

}
