package org.springboot.into.l10_intro_to_sb.L10_Intro_To_SpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L10IntroToSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
