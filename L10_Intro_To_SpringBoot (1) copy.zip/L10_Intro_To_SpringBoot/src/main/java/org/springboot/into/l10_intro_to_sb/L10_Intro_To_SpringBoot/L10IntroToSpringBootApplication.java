package org.springboot.into.l10_intro_to_sb.L10_Intro_To_SpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L10IntroToSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(L10IntroToSpringBootApplication.class, args);
	}

}
