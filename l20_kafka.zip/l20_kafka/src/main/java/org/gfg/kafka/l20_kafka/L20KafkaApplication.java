package org.gfg.kafka.l20_kafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L20KafkaApplication {

	public static void main(String[] args) {
		SpringApplication.run(L20KafkaApplication.class, args);
	}

}
