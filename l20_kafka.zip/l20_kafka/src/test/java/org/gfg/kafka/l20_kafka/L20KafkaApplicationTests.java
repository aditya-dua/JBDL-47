package org.gfg.kafka.l20_kafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L20KafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
